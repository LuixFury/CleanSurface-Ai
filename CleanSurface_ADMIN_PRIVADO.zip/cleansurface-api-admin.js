const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization"
};

const EMAIL_API =
  "https://script.google.com/macros/s/AKfycbz7b3kBDarKTwLN3cToTFRQ8uk14thuh7rJRUAqF7ihRic3UK4OlB5m9aVZpVE0D7dH/exec";

const PBKDF2_ITERATIONS = 100000;
const SESSION_DAYS = 30;
const ADMIN_EMAIL = "luizinfernando19@icloud.com";

function adminAutorizado(usuario) {
  return Boolean(usuario && usuario.role === "admin" && String(usuario.email || "").trim().toLowerCase() === ADMIN_EMAIL);
}

// ======================================================
// RESPOSTA JSON
// ======================================================

function respostaJSON(dados, status = 200) {
  return new Response(
    JSON.stringify(dados),
    {
      status,
      headers: {
        "Content-Type": "application/json; charset=UTF-8",
        ...CORS_HEADERS
      }
    }
  );
}

// ======================================================
// UTILITÁRIOS DE SEGURANÇA
// ======================================================

function bytesToHex(bytes) {
  return Array.from(bytes)
    .map(b => b.toString(16).padStart(2, "0"))
    .join("");
}

function hexToBytes(hex) {
  const bytes = new Uint8Array(hex.length / 2);

  for (let i = 0; i < bytes.length; i++) {
    bytes[i] = parseInt(
      hex.substring(i * 2, i * 2 + 2),
      16
    );
  }

  return bytes;
}

async function sha256(texto) {
  const dados = new TextEncoder().encode(texto);

  const hash = await crypto.subtle.digest(
    "SHA-256",
    dados
  );

  return bytesToHex(new Uint8Array(hash));
}

function gerarToken() {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);

  return bytesToHex(bytes);
}

async function gerarSenhaHash(senha) {
  const salt = new Uint8Array(16);
  crypto.getRandomValues(salt);

  const chave = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(senha),
    {
      name: "PBKDF2"
    },
    false,
    ["deriveBits"]
  );

  const bits = await crypto.subtle.deriveBits(
    {
      name: "PBKDF2",
      salt: salt,
      iterations: PBKDF2_ITERATIONS,
      hash: "SHA-256"
    },
    chave,
    256
  );

  return (
    "pbkdf2$" +
    PBKDF2_ITERATIONS +
    "$" +
    bytesToHex(salt) +
    "$" +
    bytesToHex(new Uint8Array(bits))
  );
}

async function verificarSenha(senha, senhaHash) {
  try {
    const partes = senhaHash.split("$");

    if (partes.length !== 4) {
      return false;
    }

    const algoritmo = partes[0];
    const iteracoes = Number(partes[1]);
    const saltHex = partes[2];
    const hashOriginal = partes[3];

    if (algoritmo !== "pbkdf2") {
      return false;
    }

    const salt = hexToBytes(saltHex);

    const chave = await crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode(senha),
      {
        name: "PBKDF2"
      },
      false,
      ["deriveBits"]
    );

    const bits = await crypto.subtle.deriveBits(
      {
        name: "PBKDF2",
        salt: salt,
        iterations: iteracoes,
        hash: "SHA-256"
      },
      chave,
      256
    );

    const hashCalculado =
      bytesToHex(new Uint8Array(bits));

    return hashCalculado === hashOriginal;

  } catch (erro) {
    return false;
  }
}

// ======================================================
// CPF
// ======================================================

function limparCPF(cpf) {
  return String(cpf || "")
    .replace(/\D/g, "")
    .trim();
}

function cpfValido(cpf) {
  cpf = limparCPF(cpf);

  if (!cpf) {
    return true;
  }

  if (cpf.length !== 11) {
    return false;
  }

  if (/^(\d)\1+$/.test(cpf)) {
    return false;
  }

  let soma = 0;

  for (let i = 0; i < 9; i++) {
    soma += Number(cpf[i]) * (10 - i);
  }

  let resto = (soma * 10) % 11;

  if (resto === 10) {
    resto = 0;
  }

  if (resto !== Number(cpf[9])) {
    return false;
  }

  soma = 0;

  for (let i = 0; i < 10; i++) {
    soma += Number(cpf[i]) * (11 - i);
  }

  resto = (soma * 10) % 11;

  if (resto === 10) {
    resto = 0;
  }

  return resto === Number(cpf[10]);
}

// ======================================================
// AUTENTICAÇÃO
// ======================================================

async function obterUsuario(request, env) {

  const autorizacao =
    request.headers.get("Authorization");

  if (!autorizacao) {
    return null;
  }

  if (!autorizacao.startsWith("Bearer ")) {
    return null;
  }

  const token =
    autorizacao.substring(7).trim();

  if (!token) {
    return null;
  }

  const tokenHash =
    await sha256(token);

  const sessao =
    await env.DB.prepare(`
      SELECT
        sessoes.id AS sessao_id,
        sessoes.usuario_id,
        sessoes.expira_em,
        usuarios.nome,
        usuarios.email,
        usuarios.cpf,
        usuarios.role
      FROM sessoes
      INNER JOIN usuarios
        ON usuarios.id = sessoes.usuario_id
      WHERE sessoes.token_hash = ?
        AND datetime(sessoes.expira_em) > datetime('now')
      LIMIT 1
    `)
    .bind(tokenHash)
    .first();

  return sessao || null;
}

// ======================================================
// REGISTRAR ACESSO
// ======================================================

async function registrarAcesso(
  env,
  usuarioId,
  evento
) {
  try {
    await env.DB.prepare(`
      INSERT INTO acessos
      (usuario_id, evento)
      VALUES (?, ?)
    `)
    .bind(
      usuarioId || null,
      evento
    )
    .run();
  } catch (erro) {
    console.log(
      "Erro ao registrar acesso:",
      erro.toString()
    );
  }
}

// ======================================================
// WORKER
// ======================================================

export default {

  async fetch(request, env) {

    // ==================================================
    // CORS
    // ==================================================

    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: CORS_HEADERS
      });
    }

    const url =
      new URL(request.url);

    // ==================================================
    // STATUS
    // ==================================================

    if (
      request.method === "GET" &&
      url.pathname === "/"
    ) {

      return respostaJSON({
        sistema: "CleanSurface AI",
        status: "online",
        banco: "D1 conectado",
        modo: "ESP32 real",
        usuarios: "ativo"
      });
    }

    // ==================================================
    // CADASTRO
    // ==================================================

    if (
      request.method === "POST" &&
      url.pathname === "/cadastro"
    ) {

      let dados = {};

      try {
        dados = await request.json();
      } catch (erro) {
        return respostaJSON({
          sucesso: false,
          erro: "JSON inválido."
        }, 400);
      }

      const nome =
        String(dados.nome || "").trim();

      const email =
        String(dados.email || "")
          .trim()
          .toLowerCase();

      const senha =
        String(dados.senha || "");

      const cpf =
        limparCPF(dados.cpf);

      // ----------------------------------------------
      // VALIDAÇÕES
      // ----------------------------------------------

      if (!nome) {
        return respostaJSON({
          sucesso: false,
          erro: "Nome não informado."
        }, 400);
      }

      if (!email || !email.includes("@")) {
        return respostaJSON({
          sucesso: false,
          erro: "E-mail inválido."
        }, 400);
      }

      if (senha.length < 6) {
        return respostaJSON({
          sucesso: false,
          erro: "A senha precisa ter pelo menos 6 caracteres."
        }, 400);
      }

      if (!cpfValido(cpf)) {
        return respostaJSON({
          sucesso: false,
          erro: "CPF inválido."
        }, 400);
      }

      // Conta de administrador: cadastro público bloqueado para evitar
      // que visitantes registrem o endereço reservado.
      if (email === ADMIN_EMAIL) {
        return respostaJSON({ sucesso: false, erro: "Cadastro administrativo indisponível. Use a conta já existente." }, 403);
      }

      // ----------------------------------------------
      // VERIFICA E-MAIL
      // ----------------------------------------------

      const emailExistente =
        await env.DB.prepare(`
          SELECT id
          FROM usuarios
          WHERE email = ?
          LIMIT 1
        `)
        .bind(email)
        .first();

      if (emailExistente) {
        return respostaJSON({
          sucesso: false,
          erro: "Este e-mail já está cadastrado."
        }, 409);
      }

      // ----------------------------------------------
      // VERIFICA CPF
      // ----------------------------------------------

      if (cpf) {

        const cpfExistente =
          await env.DB.prepare(`
            SELECT id
            FROM usuarios
            WHERE cpf = ?
            LIMIT 1
          `)
          .bind(cpf)
          .first();

        if (cpfExistente) {
          return respostaJSON({
            sucesso: false,
            erro: "Este CPF já está cadastrado."
          }, 409);
        }
      }

      // ----------------------------------------------
      // HASH DA SENHA
      // ----------------------------------------------

      const senhaHash =
        await gerarSenhaHash(senha);

      // ----------------------------------------------
      // CRIA USUÁRIO
      // ----------------------------------------------

      const novoUsuario =
        await env.DB.prepare(`
          INSERT INTO usuarios
          (nome, email, senha_hash, cpf, role)
          VALUES (?, ?, ?, ?, ?)
        `)
        .bind(
          nome,
          email,
          senhaHash,
          cpf || null,
          "user"
        )
        .run();

      const usuarioId =
        novoUsuario.meta.last_row_id;

      await registrarAcesso(
        env,
        usuarioId,
        "cadastro"
      );

      return respostaJSON({
        sucesso: true,
        mensagem: "Cadastro realizado com sucesso.",
        usuario_id: usuarioId
      });
    }

    // ==================================================
    // LOGIN
    // ==================================================

    if (
      request.method === "POST" &&
      url.pathname === "/login"
    ) {

      let dados = {};

      try {
        dados = await request.json();
      } catch (erro) {
        return respostaJSON({
          sucesso: false,
          erro: "JSON inválido."
        }, 400);
      }

      const email =
        String(dados.email || "")
          .trim()
          .toLowerCase();

      const senha =
        String(dados.senha || "");

      if (!email || !senha) {
        return respostaJSON({
          sucesso: false,
          erro: "E-mail e senha são obrigatórios."
        }, 400);
      }

      // ----------------------------------------------
      // PROCURA USUÁRIO
      // ----------------------------------------------

      const usuario =
        await env.DB.prepare(`
          SELECT *
          FROM usuarios
          WHERE email = ?
          LIMIT 1
        `)
        .bind(email)
        .first();

      if (!usuario) {
        return respostaJSON({
          sucesso: false,
          erro: "E-mail ou senha incorretos."
        }, 401);
      }

      // ----------------------------------------------
      // CONFERE SENHA
      // ----------------------------------------------

      const senhaCorreta =
        await verificarSenha(
          senha,
          usuario.senha_hash
        );

      if (!senhaCorreta) {
        await registrarAcesso(
          env,
          usuario.id,
          "tentativa_login_falhou"
        );

        return respostaJSON({
          sucesso: false,
          erro: "E-mail ou senha incorretos."
        }, 401);
      }

      // ----------------------------------------------
      // CRIA SESSÃO
      // ----------------------------------------------

      const token =
        gerarToken();

      const tokenHash =
        await sha256(token);

      const expiraEm =
        new Date(
          Date.now() +
          SESSION_DAYS *
          24 *
          60 *
          60 *
          1000
        )
        .toISOString();

      await env.DB.prepare(`
        INSERT INTO sessoes
        (usuario_id, token_hash, expira_em)
        VALUES (?, ?, ?)
      `)
      .bind(
        usuario.id,
        tokenHash,
        expiraEm
      )
      .run();

      await registrarAcesso(
        env,
        usuario.id,
        "login"
      );

      return respostaJSON({
        sucesso: true,
        mensagem: "Login realizado com sucesso.",
        token: token,
        usuario: {
          id: usuario.id,
          nome: usuario.nome,
          email: usuario.email,
          cpf: usuario.cpf,
          role: usuario.role
        }
      });
    }

    // ==================================================
    // USUÁRIO LOGADO
    // ==================================================

    if (
      request.method === "GET" &&
      url.pathname === "/usuario"
    ) {

      const usuario =
        await obterUsuario(
          request,
          env
        );

      if (!usuario) {
        return respostaJSON({
          sucesso: false,
          logado: false,
          erro: "Sessão inválida ou expirada."
        }, 401);
      }

      return respostaJSON({
        sucesso: true,
        logado: true,
        usuario: {
          id: usuario.usuario_id,
          nome: usuario.nome,
          email: usuario.email,
          cpf: usuario.cpf,
          role: usuario.role
        }
      });
    }

    // ==================================================
    // LOGOUT
    // ==================================================

    if (
      request.method === "POST" &&
      url.pathname === "/logout"
    ) {

      const usuario =
        await obterUsuario(
          request,
          env
        );

      const autorizacao =
        request.headers.get("Authorization");

      if (autorizacao &&
          autorizacao.startsWith("Bearer ")) {

        const token =
          autorizacao.substring(7).trim();

        const tokenHash =
          await sha256(token);

        await env.DB.prepare(`
          DELETE FROM sessoes
          WHERE token_hash = ?
        `)
        .bind(tokenHash)
        .run();
      }

      if (usuario) {
        await registrarAcesso(
          env,
          usuario.usuario_id,
          "logout"
        );
      }

      return respostaJSON({
        sucesso: true,
        mensagem: "Logout realizado."
      });
    }

    // ==================================================
    // INICIAR ANÁLISE
    // SITE → API
    // ==================================================

    if (
      request.method === "POST" &&
      url.pathname === "/iniciar-analise"
    ) {

      const usuario =
        await obterUsuario(
          request,
          env
        );

      if (!usuario) {
        return respostaJSON({
          sucesso: false,
          erro: "É necessário estar logado para iniciar uma análise."
        }, 401);
      }

      let dados = {};

      try {
        dados = await request.json();
      } catch (erro) {
        dados = {};
      }

      const email =
        String(
          dados.email ||
          usuario.email ||
          ""
        ).trim();

      const novaAnalise =
        await env.DB.prepare(`
          INSERT INTO analises
          (status, detalhe, usuario_id)
          VALUES (?, ?, ?)
        `)
        .bind(
          "aguardando_esp32",
          `email=${email}`,
          usuario.usuario_id
        )
        .run();

      const analiseId =
        novaAnalise.meta.last_row_id;

      await registrarAcesso(
        env,
        usuario.usuario_id,
        "iniciar_analise"
      );

      return respostaJSON({
        sucesso: true,
        analise_id: analiseId,
        status: "aguardando_esp32",
        mensagem:
          "Análise solicitada. Aguardando ESP32-S3-CAM."
      });
    }

    // ==================================================
    // ESP32 VERIFICA ANÁLISE
    // ==================================================

    if (
      request.method === "GET" &&
      url.pathname === "/verificar-analise"
    ) {

      const analise =
        await env.DB.prepare(`
          SELECT *
          FROM analises
          WHERE status = 'aguardando_esp32'
          ORDER BY id ASC
          LIMIT 1
        `)
        .first();

      if (!analise) {

        return respostaJSON({
          analise: false,
          mensagem:
            "Nenhuma análise pendente."
        });
      }

      await env.DB.prepare(`
        UPDATE analises
        SET status = 'processando'
        WHERE id = ?
      `)
      .bind(analise.id)
      .run();

      return respostaJSON({
        analise: true,
        analise_id: analise.id,
        mensagem:
          "Existe uma análise para realizar."
      });
    }

    // ==================================================
    // RECEBER RESULTADO
    // ESP32 → API
    // ==================================================

    if (
      request.method === "POST" &&
      url.pathname === "/resultado"
    ) {

      let dados;

      try {
        dados =
          await request.json();
      } catch (erro) {

        return respostaJSON({
          sucesso: false,
          erro: "JSON inválido."
        }, 400);
      }

      if (!dados.analise_id) {

        return respostaJSON({
          sucesso: false,
          erro:
            "analise_id não informado."
        }, 400);
      }

      // ----------------------------------------------
      // PROCURA ANÁLISE
      // ----------------------------------------------

      const analise =
        await env.DB.prepare(`
          SELECT *
          FROM analises
          WHERE id = ?
          LIMIT 1
        `)
        .bind(dados.analise_id)
        .first();

      if (!analise) {

        return respostaJSON({
          sucesso: false,
          erro:
            "Análise não encontrada."
        }, 404);
      }

      // ----------------------------------------------
      // EVITA DUPLICAÇÃO
      // ----------------------------------------------

      const resultadoExistente =
        await env.DB.prepare(`
          SELECT *
          FROM resultados
          WHERE analise_id = ?
          LIMIT 1
        `)
        .bind(dados.analise_id)
        .first();

      if (resultadoExistente) {

        return respostaJSON({
          sucesso: true,
          mensagem:
            "Esta análise já possui resultado.",
          email_enviado: false,
          analise_id:
            dados.analise_id
        });
      }

      // ----------------------------------------------
      // DADOS
      // ----------------------------------------------

      const valor =
        dados.valor !== undefined &&
        dados.valor !== null
          ? dados.valor
          : null;

      const status =
        String(
          dados.status ||
          "nao_visualizada"
        );

      const detalhe =
        String(
          dados.detalhe ||
          "Superfície não visualizada."
        );

      // ----------------------------------------------
      // SALVA RESULTADO
      // ----------------------------------------------

      await env.DB.prepare(`
        INSERT INTO resultados
        (analise_id, valor, status, detalhe)
        VALUES (?, ?, ?, ?)
      `)
      .bind(
        dados.analise_id,
        valor,
        status,
        detalhe
      )
      .run();

      // ----------------------------------------------
      // ATUALIZA ANÁLISE
      // ----------------------------------------------

      await env.DB.prepare(`
        UPDATE analises
        SET
          status = ?,
          valor = ?,
          detalhe = ?
        WHERE id = ?
      `)
      .bind(
        status,
        valor,
        detalhe,
        dados.analise_id
      )
      .run();

      // ----------------------------------------------
      // E-MAIL
      // ----------------------------------------------

      let emailEnviado = false;

      if (analise.detalhe) {

        const encontrado =
          analise.detalhe.match(
            /^email=(.*)$/
          );

        if (encontrado) {

          const email =
            encontrado[1].trim();

          if (email) {

            try {

              const respostaEmail =
                await fetch(
                  EMAIL_API,
                  {
                    method: "POST",

                    headers: {
                      "Content-Type":
                        "application/json"
                    },

                    body:
                      JSON.stringify({
                        email: email,

                        analise_id:
                          dados.analise_id,

                        resultado:
                          valor !== null
                            ? valor
                            : "Não informado",

                        valor:
                          valor !== null
                            ? valor
                            : "Não informado",

                        status:
                          status,

                        detalhe:
                          detalhe
                      })
                  }
                );

              if (respostaEmail.ok) {
                emailEnviado = true;
              }

            } catch (erro) {

              console.log(
                "Erro ao enviar e-mail:",
                erro.toString()
              );
            }
          }
        }
      }

      return respostaJSON({

        sucesso: true,

        mensagem:
          "Resultado recebido e salvo.",

        analise_id:
          dados.analise_id,

        status:
          status,

        email_enviado:
          emailEnviado
      });
    }

    // ==================================================
    // SITE CONSULTA RESULTADO
    // ==================================================

    if (
      request.method === "GET" &&
      url.pathname === "/resultado"
    ) {

      const analiseId =
        url.searchParams.get(
          "analise_id"
        );

      if (!analiseId) {

        return respostaJSON({
          disponivel: false,
          mensagem:
            "analise_id não informado."
        }, 400);
      }

      const resultado =
        await env.DB.prepare(`
          SELECT *
          FROM resultados
          WHERE analise_id = ?
          ORDER BY id DESC
          LIMIT 1
        `)
        .bind(analiseId)
        .first();

      if (!resultado) {

        return respostaJSON({
          disponivel: false,
          analise_id: analiseId,
          mensagem:
            "Nenhum resultado disponível."
        });
      }

      return respostaJSON({

        disponivel: true,

        analise_id:
          resultado.analise_id,

        valor:
          resultado.valor,

        status:
          resultado.status,

        detalhe:
          resultado.detalhe,

        criado_em:
          resultado.criado_em
      });
    }

    // ==================================================
    // HISTÓRICO DO USUÁRIO
    // ==================================================

    if (
      request.method === "GET" &&
      url.pathname === "/historico"
    ) {

      const usuario =
        await obterUsuario(
          request,
          env
        );

      if (!usuario) {

        return respostaJSON({
          sucesso: false,
          erro:
            "É necessário estar logado."
        }, 401);
      }

      const historico =
        await env.DB.prepare(`
          SELECT
            analises.id,
            analises.status,
            analises.valor,
            analises.detalhe,
            analises.criado_em,
            resultados.id AS resultado_id,
            resultados.criado_em AS resultado_criado_em
          FROM analises
          LEFT JOIN resultados
            ON resultados.analise_id = analises.id
          WHERE analises.usuario_id = ?
          ORDER BY analises.id DESC
        `)
        .bind(usuario.usuario_id)
        .all();

      return respostaJSON({
        sucesso: true,
        usuario_id:
          usuario.usuario_id,
        total:
          historico.results.length,
        historico:
          historico.results
      });
    }

    // ==================================================
    // UMA ANÁLISE DO USUÁRIO
    // ==================================================

    if (
      request.method === "GET" &&
      url.pathname === "/minha-analise"
    ) {

      const usuario =
        await obterUsuario(
          request,
          env
        );

      if (!usuario) {

        return respostaJSON({
          sucesso: false,
          erro:
            "É necessário estar logado."
        }, 401);
      }

      const analiseId =
        url.searchParams.get(
          "analise_id"
        );

      if (!analiseId) {

        return respostaJSON({
          sucesso: false,
          erro:
            "analise_id não informado."
        }, 400);
      }

      const analise =
        await env.DB.prepare(`
          SELECT
            analises.*,
            resultados.id AS resultado_id,
            resultados.valor AS resultado_valor,
            resultados.status AS resultado_status,
            resultados.detalhe AS resultado_detalhe,
            resultados.criado_em AS resultado_criado_em
          FROM analises
          LEFT JOIN resultados
            ON resultados.analise_id = analises.id
          WHERE analises.id = ?
            AND analises.usuario_id = ?
          LIMIT 1
        `)
        .bind(
          analiseId,
          usuario.usuario_id
        )
        .first();

      if (!analise) {

        return respostaJSON({
          sucesso: false,
          erro:
            "Análise não encontrada."
        }, 404);
      }

      return respostaJSON({
        sucesso: true,
        analise: analise
      });
    }

    // ==================================================
    // PAINEL ADMINISTRADOR
    // ==================================================

    if (
      request.method === "GET" &&
      url.pathname === "/admin/usuarios"
    ) {

      const usuario =
        await obterUsuario(
          request,
          env
        );

      if (!usuario) {

        return respostaJSON({
          sucesso: false,
          erro:
            "Login necessário."
        }, 401);
      }

      if (!adminAutorizado(usuario)) {

        return respostaJSON({
          sucesso: false,
          erro:
            "Acesso permitido somente para administrador."
        }, 403);
      }

      const usuarios =
        await env.DB.prepare(`
          SELECT
            id,
            nome,
            email,
            criado_em
          FROM usuarios
          ORDER BY id DESC
        `)
        .all();

      await registrarAcesso(
        env,
        usuario.usuario_id,
        "admin_visualizou_usuarios"
      );

      return respostaJSON({
        sucesso: true,
        total:
          usuarios.results.length,
        usuarios:
          usuarios.results
      });
    }

    // ==================================================
    // ADMIN - TODAS AS ANÁLISES
    // ==================================================

    if (
      request.method === "GET" &&
      url.pathname === "/admin/analises"
    ) {

      const usuario =
        await obterUsuario(
          request,
          env
        );

      if (!usuario) {

        return respostaJSON({
          sucesso: false,
          erro:
            "Login necessário."
        }, 401);
      }

      if (!adminAutorizado(usuario)) {

        return respostaJSON({
          sucesso: false,
          erro:
            "Acesso permitido somente para administrador."
        }, 403);
      }

      const analises =
        await env.DB.prepare(`
          SELECT
            analises.*,
            usuarios.nome AS usuario_nome,
            usuarios.email AS usuario_email,
            usuarios.cpf AS usuario_cpf
          FROM analises
          LEFT JOIN usuarios
            ON usuarios.id = analises.usuario_id
          ORDER BY analises.id DESC
        `)
        .all();

      await registrarAcesso(
        env,
        usuario.usuario_id,
        "admin_visualizou_analises"
      );

      return respostaJSON({
        sucesso: true,
        total:
          analises.results.length,
        analises:
          analises.results
      });
    }

    // ==================================================
    // ADMIN - ACESSOS
    // ==================================================

    if (
      request.method === "GET" &&
      url.pathname === "/admin/acessos"
    ) {

      const usuario =
        await obterUsuario(
          request,
          env
        );

      if (!usuario) {

        return respostaJSON({
          sucesso: false,
          erro:
            "Login necessário."
        }, 401);
      }

      if (!adminAutorizado(usuario)) {

        return respostaJSON({
          sucesso: false,
          erro:
            "Acesso permitido somente para administrador."
        }, 403);
      }

      const acessos =
        await env.DB.prepare(`
          SELECT
            acessos.*,
            usuarios.nome AS usuario_nome,
            usuarios.email AS usuario_email,
            usuarios.cpf AS usuario_cpf
          FROM acessos
          LEFT JOIN usuarios
            ON usuarios.id = acessos.usuario_id
          ORDER BY acessos.id DESC
          LIMIT 500
        `)
        .all();

      return respostaJSON({
        sucesso: true,
        total:
          acessos.results.length,
        acessos:
          acessos.results
      });
    }

    // ==================================================
    // ROTA NÃO ENCONTRADA
    // ==================================================

   // ==========================================
// STATUS DO ESP32
// ==========================================

if (url.pathname === "/esp/heartbeat" && request.method === "POST") {

  await env.DB.prepare(`
    UPDATE esp_status
    SET ultimo_sinal = CURRENT_TIMESTAMP
    WHERE id = 1
  `).run();

  return respostaJSON({
    conectado: true,
    mensagem: "ESP32 conectado"
  });
}

if (url.pathname === "/esp/status" && request.method === "GET") {

  const dados = await env.DB.prepare(`
    SELECT ultimo_sinal
    FROM esp_status
    WHERE id = 1
  `).first();

  if (!dados) {
    return respostaJSON({
      conectado: false
    });
  }

  const ultimo = new Date(dados.ultimo_sinal + "Z").getTime();
  const agora = Date.now();

  const conectado = (agora - ultimo) < 25000;

  return respostaJSON({
    conectado: conectado,
    ultimo_sinal: dados.ultimo_sinal
  });
}
 return respostaJSON({
      erro: "Rota não encontrada"
    }, 404);
  }
};
