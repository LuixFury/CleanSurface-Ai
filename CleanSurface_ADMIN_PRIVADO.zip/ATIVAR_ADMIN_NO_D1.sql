-- Execute somente depois de confirmar que a conta já é sua e que você consegue entrar nela.
-- Primeiro verifique:
SELECT id, nome, email, role FROM usuarios WHERE lower(email) = 'luizinfernando19@icloud.com';

-- Se essa for a sua conta existente, habilite o papel de administrador:
UPDATE usuarios SET role = 'admin' WHERE lower(email) = 'luizinfernando19@icloud.com';

-- Se houver outros administradores antigos, revogue-os somente após conferir:
SELECT id, nome, email FROM usuarios WHERE role = 'admin' AND lower(email) <> 'luizinfernando19@icloud.com';
-- Para garantir exclusividade, execute esta linha APENAS se os outros administradores não precisarem mais de acesso:
-- UPDATE usuarios SET role = 'user' WHERE role = 'admin' AND lower(email) <> 'luizinfernando19@icloud.com';
